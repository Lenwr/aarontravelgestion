<script setup>

</script>

<template>
  <div class="flex flex-col items-center py-[20%]">

    <video loop autoplay>
      <source src="/videos/submission.mp4" type="video/mp4"  >
      Votre navigateur ne supporte pas la lecture de vidéos.
    </video>
    <p class="text-black text-2xl " > Formulaire envoyée
    </p>
  </div>

</template>

<style scoped>

</style>